package com.library.service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.entity.Book;
import com.library.entity.Category;
import com.library.entity.User;
import com.library.repository.BookRepository;
import com.library.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BookRepository bookRepository;

    
    public List<Book> getRecommendationsForUser(Long userId) {
        // Fetch the user by ID
        User user = userRepository.findById(userId)
            .orElseThrow();

        Set<String> favoriteCategories = user.getReadBooks().stream()
            .map(book -> book.getCategory().getName())
            .collect(Collectors.toSet());

        List<Long> readBookIds = user.getReadBooks().stream()
            .map(Book::getId)
            .collect(Collectors.toList());

        return bookRepository.findByCategoryNameInAndIdNotIn(favoriteCategories, readBookIds);
    }
    public User markBookAsRead(Long userId, Long bookId) {
        User user = userRepository.findById(userId)
            .orElseThrow();
        Book book = bookRepository.findById(bookId)
            .orElseThrow();

        user.getReadBooks().add(book); // Add book to the user's read list
        return userRepository.save(user);
    }

    // Add a book to the user's reading list
    public User addToReadingList(Long userId, Long bookId) {
        User user = userRepository.findById(userId)
            .orElseThrow();
        Book book = bookRepository.findById(bookId)
            .orElseThrow();

        user.getReadingList().add(book); // Add book to the user's reading list
        return userRepository.save(user);
    }
    public User createUser(String username) {
        User user = new User();
        user.setUsername(username);

        return userRepository.save(user); // Saves the user and inserts data into the `user` table
    }
}
