package com.library.service;

import com.library.dto.BookDTO;
import com.library.dto.CategoryDTO;
import com.library.dto.UserDTO;
import com.library.entity.Book;
import com.library.entity.Category;
import com.library.entity.User;
import com.library.repository.BookRepository;
import com.library.repository.CategoryRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

@Service
public class BookService {

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	public Book addBook(Book book) throws Exception {
		if (bookRepository.existsByIsbn(book.getIsbn())) {
			throw new DataIntegrityViolationException("Book with the same ISBN already exists.");
		}
		Category category = categoryRepository.findByName(book.getCategory().getName());
		if (category == null) {
			category = new Category();
			category.setName(book.getCategory().getName());
			category = categoryRepository.save(category);
		}
		book.setCategory(category);
		// Handle the users who have read the book (from the DTO data)
		if (book.getUsersWhoRead() != null && !book.getUsersWhoRead().isEmpty()) {
		    List<User> usersWhoRead = new ArrayList<>();
		    
		    
		    for (User userRes : book.getUsersWhoRead()) {
		        User user = new User();
		        user.setId(userRes.getId()); 
		        user.setUsername(userRes.getUsername());
		        usersWhoRead.add(user); 
		        
		    }
		    book.setUsersWhoRead(usersWhoRead); 
		    	}

		if (book.getUsersWithInReadingList() != null && !book.getUsersWithInReadingList().isEmpty()) {
		    List<User> usersWithInReadingList = new ArrayList<>();
		    for (User userRes : book.getUsersWithInReadingList()) {
		        User user = new User();
		        user.setId(userRes.getId()); 
		        user.setUsername(userRes.getUsername()); 
		        usersWithInReadingList.add(user); 
		    }
		    book.setUsersWithInReadingList(usersWithInReadingList); // Set the list of users with the book in their reading list
		}
		
		return bookRepository.save(book);
	}

	public List<BookDTO> getAllBooks() {
		List<Book> books = bookRepository.findAll();
		return books.stream().map(book -> {
			BookDTO dto = new BookDTO();
			dto.setId(book.getId());
			dto.setIsbn(book.getIsbn());
			dto.setTitle(book.getTitle());
			dto.setAuthor(book.getAuthor());
			dto.setPublicationDate(book.getPublicationDate());

			CategoryDTO categoryDTO = new CategoryDTO();
			categoryDTO.setId(book.getCategory().getId());
			categoryDTO.setName(book.getCategory().getName());
			dto.setCategory(categoryDTO);
			
			
			// Handle the users who have read the book (from the DTO data)
			if (book.getUsersWhoRead() != null && !book.getUsersWhoRead().isEmpty()) {
			    List<UserDTO> usersWhoRead = new ArrayList<>();
			    
			    
			    for (User userRes : book.getUsersWhoRead()) {
			        UserDTO user = new UserDTO();
			        user.setId(userRes.getId()); 
			        user.setUsername(userRes.getUsername());
			        usersWhoRead.add(user); 
			        
			    }
			    dto.setUsersWhoRead(usersWhoRead); 
			    	}

			if (book.getUsersWithInReadingList() != null && !book.getUsersWithInReadingList().isEmpty()) {
			    List<UserDTO> usersWithInReadingList = new ArrayList<>();
			    for (User userRes : book.getUsersWithInReadingList()) {
			        UserDTO user = new UserDTO();
			        user.setId(userRes.getId()); 
			        user.setUsername(userRes.getUsername()); 
			        usersWithInReadingList.add(user); 
			    }
			    dto.setUsersWithInReadingList(usersWithInReadingList); // Set the list of users with the book in their reading list
			}
		
			 
			return dto;
		}).collect(Collectors.toList());
	}

	public List<BookDTO> getBooksByAuthor(String author) {
	    List<Book> books = bookRepository.findByAuthor(author);
	    
	    return books.stream().map(book -> {
	        BookDTO dto = new BookDTO();
	        dto.setId(book.getId());
	        dto.setTitle(book.getTitle());
	        dto.setAuthor(book.getAuthor());
	        dto.setIsbn(book.getIsbn());
	        dto.setPublicationDate(book.getPublicationDate());
	    	CategoryDTO categoryDTO = new CategoryDTO();
			categoryDTO.setId(book.getCategory().getId());
			categoryDTO.setName(book.getCategory().getName());
			dto.setCategory(categoryDTO);

			// Handle the users who have read the book (from the DTO data)
			if (book.getUsersWhoRead() != null && !book.getUsersWhoRead().isEmpty()) {
			    List<UserDTO> usersWhoRead = new ArrayList<>();
			    
			    
			    for (User userRes : book.getUsersWhoRead()) {
			        UserDTO user = new UserDTO();
			        user.setId(userRes.getId()); 
			        user.setUsername(userRes.getUsername());
			        usersWhoRead.add(user); 
			        
			    }
			    dto.setUsersWhoRead(usersWhoRead); 
			    	}

			if (book.getUsersWithInReadingList() != null && !book.getUsersWithInReadingList().isEmpty()) {
			    List<UserDTO> usersWithInReadingList = new ArrayList<>();
			    for (User userRes : book.getUsersWithInReadingList()) {
			        UserDTO user = new UserDTO();
			        user.setId(userRes.getId()); 
			        user.setUsername(userRes.getUsername()); 
			        usersWithInReadingList.add(user); 
			    }
			    dto.setUsersWithInReadingList(usersWithInReadingList); // Set the list of users with the book in their reading list
			}
	        return dto;
	    }).collect(Collectors.toList());
	}
	public List<BookDTO> getBooksByCategory(String category) {
	    List<Book> books = bookRepository.findByCategoryName(category);
	    
	    return books.stream().map(book -> {
	        BookDTO dto = new BookDTO();
	        dto.setId(book.getId());
	        dto.setTitle(book.getTitle());
	        dto.setAuthor(book.getAuthor());
	        dto.setIsbn(book.getIsbn());
	        dto.setPublicationDate(book.getPublicationDate());
	        CategoryDTO categoryDTO = new CategoryDTO();
			categoryDTO.setId(book.getCategory().getId());
			categoryDTO.setName(book.getCategory().getName());
			dto.setCategory(categoryDTO);

			// Handle the users who have read the book (from the DTO data)
			if (book.getUsersWhoRead() != null && !book.getUsersWhoRead().isEmpty()) {
			    List<UserDTO> usersWhoRead = new ArrayList<>();
			    
			    
			    for (User userRes : book.getUsersWhoRead()) {
			        UserDTO user = new UserDTO();
			        user.setId(userRes.getId()); 
			        user.setUsername(userRes.getUsername());
			        usersWhoRead.add(user); 
			        
			    }
			    dto.setUsersWhoRead(usersWhoRead); 
			    	}

			if (book.getUsersWithInReadingList() != null && !book.getUsersWithInReadingList().isEmpty()) {
			    List<UserDTO> usersWithInReadingList = new ArrayList<>();
			    for (User userRes : book.getUsersWithInReadingList()) {
			        UserDTO user = new UserDTO();
			        user.setId(userRes.getId()); 
			        user.setUsername(userRes.getUsername()); 
			        usersWithInReadingList.add(user); 
			    }
			    dto.setUsersWithInReadingList(usersWithInReadingList); // Set the list of users with the book in their reading list
			}
			return dto;
	    }).collect(Collectors.toList());
	}


	public Book updateBook(Long id, Book bookDetails) throws Exception {
		Book book = bookRepository.findById(id).orElseThrow(() -> new Exception("Book not found"));
		book.setTitle(bookDetails.getTitle());
		book.setAuthor(bookDetails.getAuthor());
		book.setPublicationDate(bookDetails.getPublicationDate());
		 if (bookDetails.getIsbn().equalsIgnoreCase(book.getIsbn())) {
		        throw new DataIntegrityViolationException("ISBN already exists for another book");
		    }

		book.setIsbn(bookDetails.getIsbn());
		if(bookDetails.getCategory()!=null && bookDetails.getCategory().getId()!=null && bookDetails.getCategory().getName()!=null) {
		Category category=new Category();
		category.setId(book.getCategory().getId());
		category.setName(book.getCategory().getName());
			book.setCategory(category);
		}
		// Handle the users who have read the book (from the DTO data)
				if (book.getUsersWhoRead() != null && !book.getUsersWhoRead().isEmpty()) {
				    List<User> usersWhoRead = new ArrayList<>();
				    
				    
				    for (User userRes : book.getUsersWhoRead()) {
				        User user = new User();
				        user.setId(userRes.getId()); 
				        user.setUsername(userRes.getUsername());
				        usersWhoRead.add(user); 
				        
				    }
				    book.setUsersWhoRead(usersWhoRead); 
				    	}

				if (book.getUsersWithInReadingList() != null && !book.getUsersWithInReadingList().isEmpty()) {
				    List<User> usersWithInReadingList = new ArrayList<>();
				    for (User userRes : book.getUsersWithInReadingList()) {
				        User user = new User();
				        user.setId(userRes.getId()); 
				        user.setUsername(userRes.getUsername()); 
				        usersWithInReadingList.add(user); 
				    }
				    book.setUsersWithInReadingList(usersWithInReadingList); // Set the list of users with the book in their reading list
				}
				
		
		return bookRepository.save(book);
	}

	public void deleteBook(Long id) throws Exception {
		Book book = bookRepository.findById(id).orElseThrow(() -> new Exception("Book not found"));
		bookRepository.delete(book);
	}
}
