package com.library.dto;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

public class BookDTO {
	private Long id;
	private String isbn;
	private String title;
	private String author;
	private LocalDate publicationDate;
	private CategoryDTO category;
	// Lists for users who read the book and those with the book in their reading list
		private List<UserDTO> usersWhoRead;
		private List<UserDTO> usersWithInReadingList;
	public BookDTO() {
		super();
	}
	public BookDTO(Long id, String isbn, String title, String author, LocalDate publicationDate, CategoryDTO category,
			List<UserDTO> usersWhoRead, List<UserDTO> usersWithInReadingList) {
		super();
		this.id = id;
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.publicationDate = publicationDate;
		this.category = category;
		this.usersWhoRead = usersWhoRead;
		this.usersWithInReadingList = usersWithInReadingList;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public LocalDate getPublicationDate() {
		return publicationDate;
	}
	public void setPublicationDate(LocalDate publicationDate) {
		this.publicationDate = publicationDate;
	}
	public CategoryDTO getCategory() {
		return category;
	}
	public void setCategory(CategoryDTO category) {
		this.category = category;
	}
	public List<UserDTO> getUsersWhoRead() {
		return usersWhoRead;
	}
	public void setUsersWhoRead(List<UserDTO> usersWhoRead) {
		this.usersWhoRead = usersWhoRead;
	}
	public List<UserDTO> getUsersWithInReadingList() {
		return usersWithInReadingList;
	}
	public void setUsersWithInReadingList(List<UserDTO> usersWithInReadingList) {
		this.usersWithInReadingList = usersWithInReadingList;
	}
	@Override
	public int hashCode() {
		return Objects.hash(author, category, id, isbn, publicationDate, title, usersWhoRead, usersWithInReadingList);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookDTO other = (BookDTO) obj;
		return Objects.equals(author, other.author) && Objects.equals(category, other.category)
				&& Objects.equals(id, other.id) && Objects.equals(isbn, other.isbn)
				&& Objects.equals(publicationDate, other.publicationDate) && Objects.equals(title, other.title)
				&& Objects.equals(usersWhoRead, other.usersWhoRead)
				&& Objects.equals(usersWithInReadingList, other.usersWithInReadingList);
	}
	@Override
	public String toString() {
		return "BookDTO [id=" + id + ", isbn=" + isbn + ", title=" + title + ", author=" + author + ", publicationDate="
				+ publicationDate + ", category=" + category + ", usersWhoRead=" + usersWhoRead
				+ ", usersWithInReadingList=" + usersWithInReadingList + "]";
	}

	
}
