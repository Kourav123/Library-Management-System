package com.library.entity;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.Proxy;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;
import jakarta.persistence.GeneratedValue;
@Entity
@JsonIgnoreProperties(ignoreUnknown = false)
@Proxy(lazy = false)
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;

    // Many-to-many relationship for books the user has read
    @ManyToMany
   // @JsonManagedReference("readBooks-reference")
    @JoinTable(name = "user_read_books", 
        joinColumns = @JoinColumn(name = "user_id"), 
        inverseJoinColumns = @JoinColumn(name = "book_id"))
    private List<Book> readBooks = new ArrayList<>();

    // Many-to-many relationship for books in the user's reading list
    @ManyToMany
  //  @JsonManagedReference("readingList-reference")
    @JoinTable(name = "user_reading_list", 
        joinColumns = @JoinColumn(name = "user_id"), 
        inverseJoinColumns = @JoinColumn(name = "book_id"))
    private List<Book> readingList = new ArrayList<>();

    // Getters and Setters
    public List<Book> getReadBooks() {
        return readBooks;
    }

    public void setReadBooks(List<Book> readBooks) {
        this.readBooks = readBooks;
    }

    public List<Book> getReadingList() {
        return readingList;
    }

    public void setReadingList(List<Book> readingList) {
        this.readingList = readingList;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
