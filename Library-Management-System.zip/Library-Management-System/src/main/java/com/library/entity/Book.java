package com.library.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

@Entity
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String isbn;
    private String title;
    private String author;
    private LocalDate publicationDate;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "category_id")
    private Category category;

    // Many-to-many relationship for users who have read this book
    @ManyToMany(mappedBy = "readBooks")
   // @JsonBackReference("readBooks-reference")  // Corresponds to 'readBooks' in User
    private List<User> usersWhoRead = new ArrayList<>();

    // Many-to-many relationship for users who have added this book to their reading list
    @ManyToMany(mappedBy = "readingList")
    //@JsonBackReference("readingList-reference")  // Corresponds to 'readingList' in User
    private List<User> usersWithInReadingList = new ArrayList<>();

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public LocalDate getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(LocalDate publicationDate) {
        this.publicationDate = publicationDate;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public List<User> getUsersWhoRead() {
        return usersWhoRead;
    }

    public void setUsersWhoRead(List<User> usersWhoRead) {
        this.usersWhoRead = usersWhoRead;
    }

    public List<User> getUsersWithInReadingList() {
        return usersWithInReadingList;
    }

    public void setUsersWithInReadingList(List<User> usersWithInReadingList) {
        this.usersWithInReadingList = usersWithInReadingList;
    }
}
