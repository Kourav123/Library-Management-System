package com.library.controller;

import com.library.entity.Book;
import com.library.entity.User;
import com.library.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {

	@Autowired
	private UserService userService;

	

	
	@GetMapping("/{userId}/recommendations")
    public ResponseEntity<List<Book>> getRecommendationsForUser(@PathVariable Long userId) {
        List<Book> recommendedBooks = userService.getRecommendationsForUser(userId);
        
        // If no recommendations found, return HTTP status 204 (No Content)
        if (recommendedBooks.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        
        // Return the list of recommended books
        return new ResponseEntity<>(recommendedBooks, HttpStatus.OK);
    }
	// Mark a book as read
    @PutMapping("/{userId}/read/{bookId}")
    public ResponseEntity<User> markBookAsRead(@PathVariable Long userId, @PathVariable Long bookId) {
        User user = userService.markBookAsRead(userId, bookId);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }

    // Add a book to the reading list
    @PutMapping("/{userId}/reading-list/{bookId}")
    public ResponseEntity<User> addToReadingList(@PathVariable Long userId, @PathVariable Long bookId) {
        User user = userService.addToReadingList(userId, bookId);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
    @PostMapping
    public ResponseEntity<User> createUser(@RequestParam String username) {
        User newUser = userService.createUser(username);
        return new ResponseEntity<>(newUser, HttpStatus.CREATED);
    }
}
