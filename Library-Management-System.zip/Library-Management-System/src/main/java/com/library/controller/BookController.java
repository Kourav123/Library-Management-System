package com.library.controller;

import com.library.dto.BookDTO;
import com.library.entity.Book;
import com.library.service.BookService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
@Validated
public class BookController {

	@Autowired
	private BookService bookService;

    @PostMapping(consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_JSON_UTF8_VALUE })
	public ResponseEntity<?> addBook(@RequestBody @Valid Book book, BindingResult result) {
		if (result.hasErrors()) {
			// Return detailed validation errors
			return new ResponseEntity<>(result.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		try {
			bookService.addBook(book);
			return new ResponseEntity<>("Booked Added into DB", HttpStatus.CREATED);
		} catch (DataIntegrityViolationException e) {
			// Return 409 Conflict if there's a duplicate ISBN issue
			return new ResponseEntity<>("Duplicate ISBN: " + book.getIsbn(), HttpStatus.CONFLICT);
		} catch (Exception e) {
			// Return 500 Internal Server Error for other exceptions
			return new ResponseEntity<>("Error updating book", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping
	public ResponseEntity<List<BookDTO>> getAllBooks() {
		return new ResponseEntity<>(bookService.getAllBooks(), HttpStatus.OK);
	}

	@GetMapping("/author/{author}")
	public ResponseEntity<List<BookDTO>> getBooksByAuthor(@PathVariable String author) {
		return new ResponseEntity<>(bookService.getBooksByAuthor(author), HttpStatus.OK);
	}

	@GetMapping("/category/{category}")
	public ResponseEntity<List<BookDTO>> getBooksByCategory(@PathVariable String category) {
		return new ResponseEntity<>(bookService.getBooksByCategory(category), HttpStatus.OK);
	}

	@PutMapping(value ="/{id}",consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_JSON_UTF8_VALUE })
	public ResponseEntity<?> updateBook(@PathVariable Long id, @RequestBody @Valid Book bookDetails) throws Exception {
		try {
			bookService.updateBook(id, bookDetails);
		} catch (DataIntegrityViolationException e) {
			// Return 409 Conflict if there's a duplicate ISBN issue
			return new ResponseEntity<>("Duplicate ISBN: " + bookDetails.getIsbn(), HttpStatus.CONFLICT);
		} catch (Exception e) {
			// Return 500 Internal Server Error for other exceptions
			return new ResponseEntity<>("Error updating book", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<>("Updated Successfully", HttpStatus.OK);

	}

	@DeleteMapping("/{id}")
	public ResponseEntity<HttpStatus> deleteBook(@PathVariable Long id) {
		try {
			bookService.deleteBook(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
