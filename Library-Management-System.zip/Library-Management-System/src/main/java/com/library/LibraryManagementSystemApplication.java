package com.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.fasterxml.jackson.core.StreamWriteConstraints;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@SpringBootApplication
@ComponentScan(basePackages = {"com.library"})
public class LibraryManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagementSystemApplication.class, args);
		System.out.println("Spring boot is up");
	}

	@Bean
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        StreamWriteConstraints constraints = StreamWriteConstraints.builder()
            .maxNestingDepth(2000)  // Increase the nesting depth limit
            .build();
        objectMapper.registerModule(new JavaTimeModule());

        objectMapper.getFactory().setStreamWriteConstraints(constraints);
        return objectMapper;
    }
}
